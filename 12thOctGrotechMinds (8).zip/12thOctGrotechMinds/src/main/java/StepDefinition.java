import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	
	@Given("User Logins into the Application")
	public void user_logins_into_the_application() {
		
		System.out.println("Hello");
	   
	}

	@Given("User Enters {string}")
	public void user_enters(String string) {
		System.out.println("Hello");
	   
	}

	@Given("user Enters the {string}")
	public void user_enters_the(String string) {
		System.out.println("Hello");
	   
	}

	@When("User will click on login button")
	public void user_will_click_on_login_button() {
		System.out.println("Hello");
	    
	}

	@Then("User will be navigated to the Home Page")
	public void user_will_be_navigated_to_the_home_page() {
		System.out.println("Hello");
	    
	}

	@Given("User Enters Username")
	public void user_enters_username() {
		System.out.println("Hello");
	    
	}

	@Given("User Enters Password")
	public void user_enters_password() {
		System.out.println("Hello");
	   
	}

	@Given("user Enters the EmailId")
	public void user_enters_the_email_id() {
		System.out.println("Hello");
	   
	}



	
	
	

}
