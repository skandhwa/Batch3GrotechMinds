package ActionClassEx;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RobotClassEx1 {

	public static void main(String[] args) throws AWTException, InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		driver.manage().window().maximize();
		Robot rb=new Robot();
		
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(3000);
		rb.keyPress(KeyEvent.VK_UP);
		rb.keyPress(KeyEvent.VK_UP);
		rb.keyPress(KeyEvent.VK_UP);
		rb.keyPress(KeyEvent.VK_UP);
		rb.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		
		rb.mousePress(InputEvent.BUTTON1_DOWN_MASK);

	}

}
