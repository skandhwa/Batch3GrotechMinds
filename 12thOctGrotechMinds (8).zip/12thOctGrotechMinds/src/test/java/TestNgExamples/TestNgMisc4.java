package TestNgExamples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgMisc4 {
	
	@Test
	public void test1()
	{
		System.out.println("I am test 1");
	}
	
	@Test(timeOut=3000)
	public void display1() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://toolsqa.com/testng/testng-tutorial/");
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	@Test()
	public void message1()
	{
		System.out.println("I am message1");
	}
	
	
	
	
	

}
