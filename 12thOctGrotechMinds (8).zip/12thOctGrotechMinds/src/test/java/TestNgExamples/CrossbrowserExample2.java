package TestNgExamples;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class CrossbrowserExample2 {
	
	public WebDriver driver;
	@Test
	public void displayCode()
	{
		driver.get("https://www.amazon.com");
	}
	
	

}
