package TestNgExamples;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(ListenerExample.class)
public class UseTestNgListener {
	
	
	@Test
	public void display()
	{
		System.out.println("hello");
	}
	
	@Test
	public void msg()
	{
		int x=9/0;
		System.out.println(x);
	}
	
	@Test
	public void test()
	{
		int y=9/3;
		System.out.println(y);
	}
	
	
	
	

}
