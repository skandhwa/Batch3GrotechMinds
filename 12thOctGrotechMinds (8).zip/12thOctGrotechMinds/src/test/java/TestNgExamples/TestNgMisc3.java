package TestNgExamples;

import org.testng.annotations.Test;

public class TestNgMisc3 {
	
	@Test
	public void test1()
	{
		System.out.println("I am test 1");
	}
	
	@Test(invocationCount=4)
	public void display1()
	{
		System.out.println("I am display1");
	}
	
	@Test
	public void message1()
	{
		System.out.println("I am message1");
	}
	
	
	

}
