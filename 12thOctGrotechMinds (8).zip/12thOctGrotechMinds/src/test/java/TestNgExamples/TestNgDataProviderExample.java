package TestNgExamples;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDataProviderExample {
	
	static WebDriver driver;
	
	
	public static void initializeDriver()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	}
	
	public static WebDriver getDriver()
	{
		return driver;
	}
	
	
	@DataProvider(name="dp1")
	public Object[][] dpmethod()
	
	{
		return new Object[][]
				{
		{"Java"},{"Selenium"},{"Python"},{"C++"},{"SQL"}
		};
		
		}
	
	@Test(dataProvider="dp1")
	public void searchvalue(String value)
	{
		initializeDriver();
		
	WebElement ele=	driver.findElement(By.xpath("//textarea[@id='APjFqb']"));
		ele.sendKeys(value);
		Reporter.log(value);
		ele.sendKeys(Keys.ENTER);
	
	}
	
	
}
