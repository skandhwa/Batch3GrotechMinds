package TestNgExamples;

import org.testng.annotations.Test;

public class TestNgDependentTest {
	
	@Test
	public void login()
	{
		
		System.out.println("I am login scenario");
	}
	
	@Test(dependsOnMethods= {"login"})
	public void SearchProduct()
	
	{ 
		
		System.out.println("I am search a product scenario");
	}
	
	@Test(dependsOnMethods= {"login","SearchProduct"})
	public void AddtoCart()
	
	{
		int x=9/0;
		System.out.println(x);
		
		System.out.println("I am add to cart scenario");
	}
	
	@Test(dependsOnMethods= {"login","SearchProduct","AddtoCart"},alwaysRun=true)
	public void PaymentGateway()
	
	{
		System.out.println("I am payment gateway scenario");
	}
	

}
