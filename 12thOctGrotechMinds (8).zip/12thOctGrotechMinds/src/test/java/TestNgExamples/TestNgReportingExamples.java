package TestNgExamples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgReportingExamples {
	
	@Test
	public void openPage()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		Reporter.log("Google page got opened");
	}
	

}
