package TestNgExamples;

import org.testng.annotations.Test;

public class TestNgMIscConcepts 

{
	@Test
	public void display()
	{
		System.out.println("Hello");
	}
	
	
	@Test(enabled=false)
	public void display1()
	{
		System.out.println("Hello1");
	}

	@Test
	public void display2()
	{
		System.out.println("Hello2");
	}
}
