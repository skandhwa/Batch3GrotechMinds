package TestNgExamples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RetryFailedCases 
{

@Test(retryAnalyzer=TestNgExamples.RetryAnalyzer.class)


	public void display()
	{
	String actualTitle="Google1";
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(actualTitle, title);
		System.out.println("Test case passed");
		
		
		
		
		
	}
	
}




