package TestNgExamples;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserExample {
	
	public WebDriver driver;
	
	@Parameters("browser")
	
	@BeforeClass
	public void preReq(String browser)
	{
		if(browser.equals("firefox"))
		{
			driver=new FirefoxDriver();
		}
		else if(browser.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
		}
		
		
		
	}
	
	
	@Test
	public void enterWord()
	{
		driver.manage().window().maximize();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
	WebElement ele=	driver.findElement(By.xpath("//input[@id='vfb-5']"));
		Dimension d=ele.getSize();
		
		int x=d.height;
		System.out.println("Height of element is "+x);
		
		int y=d.width;
		System.out.println("Width of element is "+y);
		
		Point p=ele.getLocation();
		System.out.println("x cordinates are "+p.x);
		System.out.println("y cordinates are "+p.y);
	}
	
	
	
	
	
	@AfterClass
	
	public void closeDriver() throws InterruptedException
	{
		Thread.sleep(9000);
		driver.close();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
