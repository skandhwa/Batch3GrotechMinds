package TestNgExamples;

import org.testng.annotations.Test;

public class TestNgPriorityExamples {
	
	
	@Test(priority=0)
	public void D()
	{
		System.out.println("This is priority 0");//3
	}
	
	@Test(priority=-5)
	public void B()
	{
		System.out.println("This is priority -5");//1
	}
	
	@Test(priority=-4)
	public void F()
	{
		System.out.println("This is priority -4");//2
	}

	@Test(priority=1)
	public void C()
	{
		System.out.println("This is priority 1-C");//5
	}
	
	@Test(priority=1)
	public void A()
	{
		System.out.println("This is priority 1-A");//4
	}
	
	@Test(priority='D')
	public void E()
	{
		System.out.println("This is priority D");//6
	}
	
	@Test(priority=100)
	public void G()
	{
		System.out.println("This is priority 100");//6
	}



}
