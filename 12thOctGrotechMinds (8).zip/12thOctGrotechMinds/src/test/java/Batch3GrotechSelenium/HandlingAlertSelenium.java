package Batch3GrotechSelenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class HandlingAlertSelenium {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.automationtesting.in/Alerts.html");
		Thread.sleep(3000);
//		driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
//		Thread.sleep(3000);
//		driver.switchTo().alert().accept();
		
//		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		driver.switchTo().alert().dismiss();
//	String text=	driver.findElement(By.xpath("//p[@id='demo']")).getText();
//		System.out.println(text);
//		String OrgString="You Pressed Cancel and";
//		Assert.assertEquals(OrgString, text);
//		
//		System.out.println("Our Scenario is Pass");
		
		driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Thread.sleep(3000);
		Alert alert=driver.switchTo().alert();
		alert.sendKeys("Saurabh");
		Thread.sleep(3000);
		alert.accept();
		Thread.sleep(3000);
		
		String Text=driver.findElement(By.xpath("//p[@id='demo1']")).getText();
		Thread.sleep(3000);
		System.out.println(Text);
		
		
		
		
		
		
		
		

	}

}
