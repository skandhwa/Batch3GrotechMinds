package Batch3GrotechSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands2 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
	boolean flag=	driver.findElement(By.xpath("//input[@name='form_id']")).isDisplayed();
		System.out.println(flag);
		
	boolean flag2=	driver.findElement(By.xpath("//input[@id='vfb-13-address']")).isEnabled();
		System.out.println(" Is The button  present "+flag2);
		
		
		

	}

}
