package Batch3GrotechSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands3 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		//driver.findElement(By.xpath("//input[@id='vfb-20-0']")).click();
		Thread.sleep(3000);
		
//	boolean flag=	driver.findElement(By.xpath("//input[@id='vfb-20-0']")).isSelected();
//		System.out.println(flag);
		
	WebElement ele=	driver.findElement(By.xpath("//input[@id='vfb-20-0']"));
		
	if(ele.isSelected()==false)
	{
		ele.click();
	}
	
		
		
		

	}

}
