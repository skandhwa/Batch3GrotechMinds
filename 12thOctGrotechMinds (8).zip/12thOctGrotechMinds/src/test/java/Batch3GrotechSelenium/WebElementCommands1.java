package Batch3GrotechSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		driver.findElement(By.xpath("//input[@id='vfb-5']")).sendKeys("saurabh");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='vfb-5']")).clear();
		driver.findElement(By.xpath("(//input[@name='vfb-31'])[1]")).click();
		
		boolean flag=driver.findElement(By.xpath("//input[@id='vfber56-5']")).isDisplayed();
		System.out.println(flag);

	}

}
