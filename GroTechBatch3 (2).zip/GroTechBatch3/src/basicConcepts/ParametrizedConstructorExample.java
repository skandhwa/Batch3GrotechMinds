package basicConcepts;

class Employee2
{
	int id;
	String name;
	Employee2(int i,String n)
	{
		id=i;
		name=n;
	}
	
	void test()
	{
		System.out.println("The Employee id is " +id);
		System.out.println("The name is " +name);
	}
}
public class ParametrizedConstructorExample {

	public static void main(String[] args) {
		
		Employee2 obj=new Employee2(123,"Saurabh");
		obj.test();
		Employee2 obj1=new Employee2(145,"Harish");
		obj1.test();
	}

}
