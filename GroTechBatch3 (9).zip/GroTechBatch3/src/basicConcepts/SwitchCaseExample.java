package basicConcepts;

public class SwitchCaseExample {

	public static void main(String[] args) {
		
		int a,b,c;
		int choice=1;
		
		
		switch(choice)
		{
		case 1:
			a=10;
			b=20;
		    c=a+b;
		    System.out.println(c);
		    break;
		    
		case 2:
			a=30;
			b=20;
		    c=a-b;
		    System.out.println(c);
		  //  break;
		    
		case 3:
			a=30;
			b=20;
		    c=a*b;
		    System.out.println(c);
		  //  break; 
		case 4:
			a=30;
			b=20;
		    c=a/b;
		    System.out.println(c);
		    break;
		    
		default:
			System.out.println("This is invalid");
			
			
			
		
		
		}
		
		

	}

}
