package basicConcepts;

class DE
{
	String name;
	int id;
	
	DE(String name,int id)
	{
		this.name=name;
		this.id=id;
	}
	
	void display()
	{
		System.out.println(name);
		System.out.println(id);
	}
	
}
public class WithoutThisExample {

	public static void main(String[] args) {
		
		DE obj=new DE("Saurabh",1234);
		obj.display();

	}

}
