package basicConcepts;

public class RightAnglePattern {

	public static void main(String[] args) {
		
		int i,j,row=5;
		
		for(i=0;i<row;i++)//0<5//1<5//2<5
		{
			for(j=0;j<=i;j++)//j=0,0<=2//1<=2//2<=2
			{
				System.out.print("* ");
			}
			
			System.out.println();
		}
		
		
		

	}

}
