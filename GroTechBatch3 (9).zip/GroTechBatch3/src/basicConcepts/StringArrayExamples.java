package basicConcepts;

public class StringArrayExamples {

	public static void main(String[] args) {
		
		String[] a= new String[] {"Saurabh","Manish","Rahul"};
		
		String[]b= {"Anil","Rohit","Shyam"};
		
		String[]c=new String[3];
		
		c[0]="Mani";
		c[1]="Ravi";
		c[2]="Harish";
		
		for(String x:a)
		{
			System.out.println(x);
		}
		
		System.out.println();
		System.out.println();
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		

	}

}
