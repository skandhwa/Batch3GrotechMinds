package basicConcepts;

class Employee
{
	int id;
	String name;


void display()
{
	System.out.println("The employee id is  "+id);
	System.out.println("The name is  "+name);
}
}

public class ConstructorExample2 {

	public static void main(String[] args) {
		
		Employee obj=new Employee();
		obj.display();
		
		
		
	}
		

	}


