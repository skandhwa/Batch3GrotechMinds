package Batch3GrotechSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class GetFirstSelectedOptionsEx {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.automationtesting.in/Register.html");
	WebElement ele=	driver.findElement(By.xpath("//select[@id='Skills']"));
	Select oselect=new Select(ele);
	oselect.selectByIndex(2);
WebElement ele2=	oselect.getFirstSelectedOption();
String value=ele2.getText();
System.out.println(value);
	
		
	}

}
