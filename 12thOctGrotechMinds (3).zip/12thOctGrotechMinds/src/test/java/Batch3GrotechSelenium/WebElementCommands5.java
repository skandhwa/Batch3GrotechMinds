package Batch3GrotechSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands5 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
	WebElement ele2=	driver.findElement(By.xpath("(//span[@class='select2-selection select2-selection--single'])[1]"));
	 String name=   ele2.getTagName();
	 System.out.println(name);

	}

}
