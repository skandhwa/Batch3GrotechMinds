package Batch3GrotechSelenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectMultipleValuesDropdown {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
	WebElement ele=	driver.findElement(By.xpath("//select[@id='selenium_commands']"));
		
	Select oselect =new Select(ele);
	if(oselect.isMultiple())
	{
		oselect.selectByIndex(0);
		oselect.selectByIndex(1);
		oselect.selectByIndex(2);
	}
	Thread.sleep(3000);
	
List <WebElement> li=	oselect.getAllSelectedOptions();

for(int i=0;i<li.size();i++)
{
	System.out.println(li.get(i).getText());
}

Thread.sleep(3000);
	
	//oselect.deselectAll();
	oselect.deselectByIndex(1);
	oselect.deselectByIndex(2);
	
	
	
		

	}

}
