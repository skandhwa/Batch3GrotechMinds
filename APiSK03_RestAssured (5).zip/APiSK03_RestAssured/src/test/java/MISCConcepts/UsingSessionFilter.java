package MISCConcepts;

import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.filter.session.SessionFilter;

public class UsingSessionFilter {
	
	
	@BeforeSuite
	public SessionFilter prereq()
	{
	SessionFilter s=new SessionFilter();
	return s;
	}
	
	
	
	@Test
	public void display()
	{
		SessionFilter s=new SessionFilter();
		RestAssured.baseURI="https://httpbin.org";
		HashMap<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("firstname", "Tom");
		mp.put("lastname","wick");
		mp.put("IsMarried",true);
		String Response=		given().log().all().filter(s).
				headers("Content-Type","application/json")
				.body(mp)
				.when().post("post").then().log().all().extract()
				.response().asString();

		System.out.println(Response);
	}
	
	@Test
	public void test()
	{
		
	}
	

}
