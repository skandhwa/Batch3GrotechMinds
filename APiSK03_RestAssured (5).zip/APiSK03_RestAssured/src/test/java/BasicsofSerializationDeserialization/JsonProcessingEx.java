package BasicsofSerializationDeserialization;

public class JsonProcessingEx {
	
	public String name;
	public String job;
	public int id;
	public String createdAt;
	
	
	

}
