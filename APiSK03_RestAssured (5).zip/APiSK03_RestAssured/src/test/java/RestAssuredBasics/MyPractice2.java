package RestAssuredBasics;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;

import org.testng.Assert;

public class MyPractice2 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		int Actual_Page=2;
		int total_pages=2;
		String FirstName="Byron";
		
	String Response=	given().log().all().queryParam("page",2)
		
		.header("Connection","keep-alive")
		.when().get("/api/users")
		.then().log().all()
		.assertThat().statusCode(200)
		.extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	
	String ExpectedFirstName=js.getString("data[3].first_name");
	int Expected_Per_Page=js.getInt("per_page");
	
	
	
	Assert.assertEquals(FirstName, ExpectedFirstName);
	
		
		
		
		
		

	}

}
