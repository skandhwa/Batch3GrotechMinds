package RestAssuredBasics;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static org.hamcrest.Matchers.*;

import org.testng.Assert;

import static io.restassured.RestAssured.given;

public class MyPractice1 {

	public static void main(String[] args) {
		
		
		String ActualLastname="Weaver";
		String ActualEmail="janet.weaver@reqres.in";
		int Actal_ID=2;
		
		
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all().headers("Connection","keep-alive")
		.when().get("api/users/2")
		.then().log().all().assertThat().statusCode(200).
		body("data.first_name",equalTo("Janet")).
		
		headers("Server","cloudflare").
		
		
		extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	String LastName=js.getString("data.last_name");
	Assert.assertEquals(ActualLastname, LastName);
	
	
	String Email=js.getString("data.email");
	int ID=js.getInt("data.id");
	
	Assert.assertEquals(ActualEmail, Email);
	Assert.assertEquals(Actal_ID, ID);
	
	System.out.println("My Test case passed");
	
	
	
	
	
	
	
	
		
		
		
		

	}

}
