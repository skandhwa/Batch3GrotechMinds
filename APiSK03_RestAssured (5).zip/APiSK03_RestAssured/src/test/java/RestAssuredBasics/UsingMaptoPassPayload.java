package RestAssuredBasics;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class UsingMaptoPassPayload {

	public static void main(String[] args) {
		
		RestAssured.baseURI="http://httpbin.org";
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("name", "morpheus");
		mp.put("job", "leader");
		mp.put("id", 1234);
		mp.put("isActive", 'Y');
		
		Map<String,Object> mp2=new LinkedHashMap<String,Object>();
		mp2.put("name", "Tom");
		mp2.put("job", "QA");
		mp2.put("id", 9234);
		mp2.put("isActive", 'N');
		
		Map<String,Object> mp3=new LinkedHashMap<String,Object>();
		mp3.put("name", "Harry");
		mp3.put("job", "Dev");
		mp3.put("id", 8234);
		mp3.put("isActive", 'Y');
		
		List<Map> li=new ArrayList<Map>();
		li.add(mp);
		li.add(mp2);
		li.add(mp3);
		
		
		
	String Response=	given().log().all().body(li).headers("Content-type","application/json")
		.when().post("post").then().log().all()
		.assertThat().statusCode(200).extract().response().asString();
	
	
	System.out.println(Response);
		

	}

}
