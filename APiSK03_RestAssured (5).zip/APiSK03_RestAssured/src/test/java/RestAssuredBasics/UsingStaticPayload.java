package RestAssuredBasics;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.testng.Assert;

import PayloadData.Payload1;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class UsingStaticPayload {

	public static void main(String[] args) throws IOException {
		
		
String Current_Date="2024-07-24";
		
		RestAssured.baseURI="https://reqres.in";
		
		String Response=	
				given().log().all().header("Connection","keep-alive")
				.header("Content-Type","application/json")
				
				.body( new String(Files.readAllBytes(Paths.get("E:\\APISK03_TestData24thJuly.txt"))
						
						)).
				
				
			when().post("api/users")
			
			
			.then().log().all().assertThat().statusCode(201).extract().response()
			.asString();
		
		System.out.println(Response);
		
		JsonPath js=new JsonPath(Response);
	String CreatedDate=	js.getString("createdAt");
	
String[]ch=	CreatedDate.split("T");
System.out.println(ch[0]);
System.out.println(ch[1]);

Assert.assertEquals(ch[0], Current_Date);
System.out.println("Test Case passed");

	}

}
