package RestAssuredBasics;

import org.testng.Assert;

import PayloadData.MockResponses;
import io.restassured.path.json.JsonPath;

public class ValidationMockResponse {

	public static void main(String[] args) {
		
		
		JsonPath js=new JsonPath(MockResponses.Courses());
		
		////Print No of courses returned by API
		
		int size=js.getInt("courses.size()");
		System.out.println("Total number of courses are "+size);
		
		///Print Purchase Amount
		
		int purchaseamount=js.getInt("dashboard.purchaseAmount");
		System.out.println("Total purchase amount is "+purchaseamount);

		///Print Title of the first course

		String title=js.getString("courses[0].title");
		System.out.println("title of first course is "+title);
		
		// Print All course titles and their respective Prices
		
		for(int i=0;i<size;i++)//i=0,0<3//i=2,2<3
		{
			String CourseValues=js.getString("courses["+i+"].title");
			String CoursePrice=js.getString("courses["+i+"].price");
			System.out.println(CourseValues);
			System.out.println(CoursePrice);
			
			
		}
		
		////Print no of copies sold by RPA Course
		
	String copy=	js.getString("courses[2].copies");
	System.out.println("The number of copies sold by RPA are "+copy);
	
	
	
	///Verify if Sum of all Course prices matches with Purchase Amount
	int sum=0;
	for(int i=0;i<size;i++)//i=0,0<3//i=1,1<3//i=2,2<3
	{
		int CourseCopies=js.getInt("courses["+i+"].copies");//6//4//10
		int CoursePrice=js.getInt("courses["+i+"].price");//50//40//45
		int amount=CourseCopies*CoursePrice;///amount=50*6=300///amount=40*4=160////450
		
		sum=sum+amount;///sum=0+300=300///sum=300+160=460///sum=450+460=910
		
		
		
		
	}
	
	Assert.assertEquals(purchaseamount, sum);
	System.out.println("Test case passed");
	
	
	

		
		
		

	}

}
