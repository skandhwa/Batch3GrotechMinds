package RestAssuredBasics;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PayloadData.Payload1;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;


public class UsingDataProviderinRestAssured {
	
	@DataProvider(name="Booksdata")
	public Object [][] getData()
	{
		return new Object[][]
				{
			
			{"xbhdtre","56784"},
			{"jkysetew","A98765"},
			{"UTRvghj","U65432"}
			
				};
				}
	
	
	@Test(dataProvider="Booksdata")
	public void addbook(String isbn,String aisle)
	{
	String Response=	RestAssured.baseURI="http://216.10.245.166";
		given().log().all().headers("Content-Type","application/json")
		.body(Payload1.addBook(isbn, aisle))
		.when().post("Library/Addbook.php")
		.then().log().all().assertThat().statusCode(200).extract().response().asString();
		
	
	System.out.println(Response);
	
//	JsonPath js=new JsonPath(Response);
//	String Expected_Msg=js.getString("Msg");
//	Assert.assertEquals("successfully added",Expected_Msg);
//	System.out.println("Test Case passed");
	
		
		
		
		
	}
	
	
	

}
