package PassingJSONPayload;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class SendingSelfCreatedJSON {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://httpbin.org";
		HashMap<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("firstname", "Tom");
		mp.put("lastname","wick");
		mp.put("IsMarried",true);
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("Music");
		li.add("Criket");
		li.add("Movies");
		
		mp.put("Hobbies",li);
		
		
		HashMap<String,String> mp1=new LinkedHashMap<String,String>();
		mp1.put("Programming language", "Java");
		mp1.put("WebAutomation","Selenium");
		mp1.put("API Testing","RestAssured");
		
		mp.put("TechSkill", mp1);
		
		
		
		
		
		
String Response=		given().log().all().headers("Content-Type","application/json")
		.body(mp)
		.when().post("post").then().log().all().extract()
		.response().asString();

System.out.println(Response);
		
		

	}

}
