package AuthenticationExamples;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class APIKeyAuthentication {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://api.openweathermap.org";
		String Response=	given().log().all().queryParam("q", "Delhi")
				.queryParam("appid", "c4a82761751d8c4a1482e529b39852ad")
				.when().get("data/2.5/weather")
				.then().log().all().
				extract().response().asString();
		
		System.out.println(Response);
		
		
		JsonPath js=new JsonPath(Response);
	String BaseValue=	js.getString("base");
	System.out.println(BaseValue);
	int TimeZone=js.getInt("timezone");	
	System.out.println(TimeZone);
		

	}

}
