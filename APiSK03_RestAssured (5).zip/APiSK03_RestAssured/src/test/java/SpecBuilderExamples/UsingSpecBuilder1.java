package SpecBuilderExamples;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;

import PayloadData.Payload1;

public class UsingSpecBuilder1 {

	public static void main(String[] args) {
		
		
		RequestSpecification req=new RequestSpecBuilder()
				.setBaseUri("https://reqres.in/")
				.setContentType(ContentType.JSON).build();
		
		
		RequestSpecification res=given().log().all()
				.spec(req).body(Payload1.addDetails("Tom","QA"));
		
		
		ResponseSpecification respec= new ResponseSpecBuilder()
				.expectStatusCode(201).expectContentType(ContentType.JSON)
				.expectHeader("Server","cloudflare").build();
		
String response=		res.when().post("api/users").then().log().all().
		spec(respec).extract().response().asString();

System.out.println(response);
		
		
		
		
		
				
				
		
		

	}

}
