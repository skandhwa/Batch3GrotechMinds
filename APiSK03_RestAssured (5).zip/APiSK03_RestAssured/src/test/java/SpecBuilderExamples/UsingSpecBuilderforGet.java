package SpecBuilderExamples;

import org.testng.annotations.Test;

import CommonFunctions.ReqandResponseSpecifications;

import static io.restassured.RestAssured.*;

import io.restassured.specification.RequestSpecification;

public class UsingSpecBuilderforGet {
	
	@Test
	public void validateGetRequest()
	{
		
		RequestSpecification req= given().log().all().queryParam("page",2).
				spec(ReqandResponseSpecifications.requestMethod());
		
		
	String Response=	req.when().get("api/users/2").then().log().all()
		.spec(ReqandResponseSpecifications.responseMethod(200))
		.extract().response().asString();
	
	
	System.out.println(Response);
	
	
		
		
				
		
	}
	

}
