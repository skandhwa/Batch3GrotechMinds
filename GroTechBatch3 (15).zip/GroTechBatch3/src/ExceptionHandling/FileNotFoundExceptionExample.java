package ExceptionHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileNotFoundExceptionExample {

	public static void main(String[] args) {
		

			try {
				FileInputStream fs=new FileInputStream("C:\\Users\\saura\\OneDrive\\Documents\\TestData2607.xlsx");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

		
		
		

	}

}
