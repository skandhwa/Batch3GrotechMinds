package ExceptionHandling;

public class finallyblockex {

	public static void main(String[] args) {
		
		try
		{
			int x=20;
			int y=x/0;
			System.out.println(y);
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		
		finally
		{
			System.out.println("I will always execute");
		}
		
		

	}

}
