package ExceptionHandling;

public class throwExample {
	
	public static void validateage(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("You are not Elligible");
			//System.out.println("You are not elligible");
		}
		
		else
		{
			System.out.println("You are elligible to vote");
		}
	}
	

	public static void main(String[] args) {
		
		throwExample.validateage(14);
		System.out.println("Enter the pooling station");
		System.out.println("Rest of process");
		
	
		
		
		

	}

}
