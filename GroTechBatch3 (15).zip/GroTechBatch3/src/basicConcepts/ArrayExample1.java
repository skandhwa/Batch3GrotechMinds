package basicConcepts;

public class ArrayExample1 {

	public static void main(String[] args) {
		
		
		int a[]=new int [5];
		a[0]=10;
		a[1]=20;
		a[2]=30;
		a[3]=40;
		a[4]=60;
		//a[5]=90;
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		System.out.println();
		System.out.println();
		
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
