package basicConcepts;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadDatafromFile {

	public static void main(String[] args) throws FileNotFoundException {
		
		File f2=new File("D:\\03rdOctoberFileNew\\SaurabhNew.txt");
		Scanner obj=new Scanner(f2);
		
		while(obj.hasNextLine())
		{
			String data_file=obj.nextLine();
			System.out.println(data_file);
			
			
		}
		
		obj.close();
		
		

	}

}
