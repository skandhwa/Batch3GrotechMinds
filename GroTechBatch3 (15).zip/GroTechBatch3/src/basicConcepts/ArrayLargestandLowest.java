package basicConcepts;

public class ArrayLargestandLowest {
	
	public static int getthirdlar(int a[],int total)
	{
		int temp=0;
	
		for(int i=0;i<total;i++)//i=1,1<4
		{
			for(int j=i+1;j<total;j++)//j=4,2<4
			{
				if(a[i]>a[j])//a[0]>a[2]//a[1]>a[3]
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}												
							}
			
		///return a[total-3]//third largest					
		}
		return a[3-1];////third smallest
			}
	
	
	public static void main(String[] args) {
		
		int a[]= {19,12,85,27,36,45};
	System.out.println("Third largest element is  "+getthirdlar(a,6));	
		
		
	}

}
