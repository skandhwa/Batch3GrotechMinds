package basicConcepts;

interface DF
{
	void draw();
	default void display()
	{
		System.out.println("Hello");
	}
}

class DT implements DF
{
	public void draw()
	{
		System.out.println("I am draw method");
	}
}



public class interfacewithDefaultMethod {

	public static void main(String[] args) {
		
		DF ref=new DT();
		ref.display();
		ref.draw();

	}

}
