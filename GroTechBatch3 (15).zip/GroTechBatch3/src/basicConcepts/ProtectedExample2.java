package basicConcepts;

public class ProtectedExample2 {

	public static void main(String[] args) {
		
		ProtectedExample1 obj=new ProtectedExample1();
		obj.display();
		

	}

}
