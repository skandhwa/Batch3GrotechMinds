package basicConcepts;

import java.io.File;

public class DeleteAFile {

	public static void main(String[] args) {
		
		File f=new File("D:\\03rdOctoberFileNew\\SauwewrabhNew.txt");
		boolean flag=f.delete();
		System.out.println(flag);
		

	}

}
