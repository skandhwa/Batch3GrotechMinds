package Collectionsexample;

import java.util.ArrayList;

public class ArrayListMethod4 {

	public static void main(String[] args) {
		
		ArrayList<String> lang=new ArrayList<String>();
		lang.add("C");
		lang.add("Java");
		lang.add("Python");
		lang.add("Ruby");
		int x=lang.size();
		
		for(String str:lang)
		{
			System.out.println(str);
		}
		
		String[] arr=new String[x];
		lang.toArray(arr);
		
		
		System.out.println("Elements of array are ");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
		
		
		
		

	}

}
