package Collectionsexample;

import java.util.ArrayList;
import java.util.Iterator;

public class ListExample {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("Saurabh");
		li.add("Manish");
		li.add("ramesh");
		li.add("Harish");
		
		System.out.println(li);
		System.out.println();
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		System.out.println();
		System.out.println();
		Iterator it=li.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		
		
		
		
			
			
		
		
		

	}

}
