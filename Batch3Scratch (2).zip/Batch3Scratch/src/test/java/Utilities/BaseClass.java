package Utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Constants.Constants1;



public class BaseClass {
	
	
	public static WebDriver driver;
	
	public static WebDriver initializeDriver() 
	{
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		try {
			driver.get(GetDataFromExcel.getUrl());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver;
	}
	
	public static void getTitleOfPage()
	{
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	public static void AddHardcodedWait() throws InterruptedException
	{
		Thread.sleep(3000);
	}
	
	public static void takeScreenShotMethod() throws IOException
	{
		TakesScreenshot srcshot=(TakesScreenshot)driver;
		File SrcFile=srcshot.getScreenshotAs(OutputType.FILE);
		File DestFile=new File(Constants1.SCREENSHOTPATH);
		FileUtils.copyFile(SrcFile, DestFile);
	}
	
	public static void ScrollDown()
	{
		JavascriptExecutor js =(JavascriptExecutor)driver;
		js.executeScript("windows.scrollBy(0,500)","");
	}
	
	
	
	
	

}
