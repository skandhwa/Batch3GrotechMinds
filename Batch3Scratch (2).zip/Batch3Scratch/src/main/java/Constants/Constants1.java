package Constants;

public class Constants1 {
	
	public static final String TESTDATAPATH= "D:\\TestData0412\\TestData0412.xlsx";
	public static final String SCREENSHOTPATH= "E:\\EclipseWorkspace\\Batch3Scratch\\target\\Screenshot\\"+Math.random()+"image1.jpg";
}
