package basicConcepts;

interface Design
{
	void car();
	void scooter();
}

interface Manufacturing extends Design
{
	void rawmaterial();
	void mileage();
}

class Test10 implements Manufacturing
{
	public void car()
	{
		System.out.println("I am fourwheeler");
	}
	public void scooter()
	{
		System.out.println("I am twowheeler");
	}
	
	public void rawmaterial()
	{
		System.out.println("I am rawmaterial");
	}
	
	public void mileage()
	{
		System.out.println("I am mileage");
	}
	
	
}
public class InterfaceInheritance {

	public static void main(String[] args) {
		
		Manufacturing ref=new Test10();
		ref.car();
		ref.scooter();
		ref.mileage();
		ref.rawmaterial();
		

	}

}
