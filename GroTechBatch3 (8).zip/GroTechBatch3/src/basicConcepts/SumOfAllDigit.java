package basicConcepts;

public class SumOfAllDigit {

	public static void main(String[] args) {
		
		int number=789;
		int sum=0;
		
		while(number >0)///789>0//78>0///7>0//0>0
		{
			int digit=number%10;//789%10=9///78%10=8//7%10=7
			sum=sum+digit;//0+9=9///9+8=17//17+7=24
		number=	number/10;//789/10=78//78/10=7//7/10=0
		}
		
		System.out.println(sum);

	}

}
