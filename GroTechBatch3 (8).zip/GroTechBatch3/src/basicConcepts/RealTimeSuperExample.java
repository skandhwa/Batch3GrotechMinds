package basicConcepts;

class People
{
	int id;
	String name;
	People(int i,String n)
	{
		id=i;
		name=n;
	}
	
}

class Employee5 extends People
{
	float salary;
	Employee5(int i,String n,float s)
	{
		super(i,n);
		salary=s;
		
	}
	
	void display()
	{
		System.out.println(id);
		System.out.println(name);
		System.out.println(salary);
	}
	
	
	
}
public class RealTimeSuperExample {

	public static void main(String[] args) {
		
		
		Employee5 obj=new Employee5(1234,"Saurabh",700f);
		obj.display();
	}

}
