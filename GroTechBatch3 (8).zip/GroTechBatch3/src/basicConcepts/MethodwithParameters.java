package basicConcepts;

class CA
{
	float add(float a,float b,float c)///2.5,3.5,6.5=12.5
	{
		return a+b+c;
	}
}

public class MethodwithParameters {

	public static void main(String[] args) {
		
         CA obj=new CA();
   System.out.println("The sum of a and b is  "+obj.add(10,20,30));      
         
	}

}
