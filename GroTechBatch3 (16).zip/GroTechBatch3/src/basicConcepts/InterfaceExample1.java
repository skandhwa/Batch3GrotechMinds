package basicConcepts;

interface ZA
{
	void display();
	void test();
	int x=20;
	
}

class ZB implements ZA
{
	public void display()
	{
		System.out.println("I am display");
	}
	
	public void test()
	{
		System.out.println();
	}
}

public class InterfaceExample1 {

	public static void main(String[] args) {
		ZB obj=new ZB();
		obj.display();
		obj.test();

	}

}
