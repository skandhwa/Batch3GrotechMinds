package basicConcepts;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WritingtoaFile {

	public static void main(String[] args) throws IOException {
		
		
		
		
		FileWriter f1=new FileWriter("D:\\03rdOctoberFileNew\\test177.txt");
		File f=new File("D:\\03rdOctoberFileNew\\test167.txt");
		f1.append('d');
		f1.append("testn");
		f1.append("TestNew12345", 3, 5);
	
		f1.write("Java");
        f1.close();
        System.out.println("Content added to file");
        
    long y=    f.length();
    System.out.println(y);
        
        
        
        
        
        
		
		
	}

}
