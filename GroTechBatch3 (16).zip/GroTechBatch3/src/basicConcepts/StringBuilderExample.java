package basicConcepts;

public class StringBuilderExample {

	public static void main(String[] args) {
		
		StringBuilder sb=new StringBuilder("Saurabh");
//		sb.append("Grotech");
//		System.out.println(sb);
		
		
//		sb.delete(1,7);
//		System.out.println(sb);
//		
		
		sb.reverse();
		System.out.println(sb);

	}

}
