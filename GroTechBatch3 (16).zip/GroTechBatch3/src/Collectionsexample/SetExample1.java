package Collectionsexample;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class SetExample1 {

	public static void main(String[] args) {
		
		Set<String> data=new HashSet<String>();
		data.add("Saurabh");
		data.add("manoj");
		data.add("Harsh");
		data.add("Rachin");
		data.add("Rachin");
		
		for(String x:data)
		{
			System.out.println(x);
		}
		
		System.out.println();
		System.out.println();
		
		Set<String> data2=new LinkedHashSet<String>();
		data2.add("Saurabh");
		data2.add("manoj");
		data2.add("Harsh");
		data2.add("Rachin");
		data2.add("Rachin");
		
		for(String x:data2)
		{
			System.out.println(x);
		}
		
		

	}

}
