package Collectionsexample;

import java.util.ArrayList;

public class ArrayListMethods2 {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("Saurabh");
		li.add("Manish");
		li.add("ramesh");
		li.add("Harish");
		
		ArrayList<String> li2=new ArrayList<String>();
		li2.add("Gaurabh");
		li2.add("Harish");
		li2.add("mahesh");
		li2.add("samir");
		
		li.addAll(li2);
		
		for(String str:li)
		{
			System.out.println(str);
		}
		System.out.println();
		System.out.println();
		
		for(String str2:li2)
		{
			System.out.println(str2);
		}
		
		li2.clear();
		
		System.out.println("After removing all elements of array list");
		
		boolean flag7=li2.isEmpty();
		System.out.println("Is the Array List Empty "+flag7);
		
		for(String str3:li2)
		{
			System.out.println(str3);
		}
		
		

	}

}
