package Collectionsexample;

import java.util.HashSet;
import java.util.Set;

public class SetMethods4 {

	public static void main(String[] args) {
		
		Set<Integer> s=new HashSet<Integer>();
		
		s.add(23);
		s.add(45);
		s.add(56);
		s.add(67);
		
	Set<Integer> s2=new HashSet<Integer>();
		
		s2.add(231);
		s2.add(145);
		s2.add(56);
		s2.add(671);
		
		s.retainAll(s2);
		
		for(int x:s)
		{
			System.out.println(x);
		}
		
		System.out.println();
		System.out.println();
		
		
		

	}

}
