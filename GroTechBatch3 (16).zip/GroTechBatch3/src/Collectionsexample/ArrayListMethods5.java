package Collectionsexample;

import java.util.ArrayList;

public class ArrayListMethods5 {

	public static void main(String[] args) {
		
		ArrayList<String>li=new ArrayList<String>();
		li.add("Saurabh");
		li.add("Manish");
		li.add("ramesh");
		li.add("Harish");
		
//		String str=li.toString();
//		System.out.println(str);
//		
//	int x=	li.lastIndexOf("Ajit");
//	System.out.println(x);
		
		ArrayList<String>li2=new ArrayList<String>();
		li2.add("Saurabh");
		li2.add("Rocky");
		li2.add("Hitesh");
		li2.add("Harish");
		
		
		li.retainAll(li2);
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		

	}

}
