package Collectionsexample;

import java.util.Arrays;
import java.util.List;

public class ArraytoarrayList {

	public static void main(String[] args) {
		
//		int []a=new int[] {3,5,6,7,12,45};
//		
//		List<int[]> li=Arrays.asList(a);
//		
//		System.out.println(li);
		
//		for(int x:li)
//		{
//			System.out.println(x);
//		}
		
		
		String []str=new String[] {"Saurabh","ramesh","harish"};
		
		List li=Arrays.asList(str);
		
		System.out.println(li);
		

	}

}
