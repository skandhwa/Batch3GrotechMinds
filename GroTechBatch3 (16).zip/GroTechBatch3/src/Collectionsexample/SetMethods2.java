package Collectionsexample;

import java.util.HashSet;
import java.util.Set;

public class SetMethods2 {

	public static void main(String[] args) {
		
		
		Set<String> data1=new HashSet<String>();
		data1.add("Saurabh");
		data1.add("manoj");
		data1.add("Harsh");
		data1.add("Rachin");
		data1.add("Rachin");
		
		int size=data1.size();
		System.out.println("The size of set is  "+size);

		
		Set<String> data2=new HashSet<String>();
		data2.add("Gaurabh");
		data2.add("manoj");
		data2.add("Utkarsh");
		data2.add("Sachin");
		
		data1.addAll(data2);
		
		for(String x:data1)
		{
			System.out.println(x);
		}
		
		boolean flag2=data1.isEmpty();
		System.out.println("Is the Set Empty before running clear  "+flag2);
		
		data1.clear();
		
		boolean flag3=data1.isEmpty();
		System.out.println("Is the Set Empty after running clear  "+flag3);
		
		
		System.out.println("After clearing elements are ");
		
		for(String y:data1)
		{
			System.out.println(y);
		}
		
		System.out.println();
		System.out.println();
		
		for(String z:data2)
		{
			System.out.println(z);
		}
		
		
	}

}
