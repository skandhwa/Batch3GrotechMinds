package Collectionsexample;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(45);
		stk.push(56);
		stk.push(67);
		for(int x:stk)
		{
			System.out.println(x);
		}
		
		stk.pop();
		stk.pop();
		
		for(int x:stk)
		{
			System.out.println(x);
		}
		
		

	}

}
