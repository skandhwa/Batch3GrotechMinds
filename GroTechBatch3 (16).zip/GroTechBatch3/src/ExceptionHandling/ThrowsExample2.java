package ExceptionHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ThrowsExample2 {

	public static void main(String[] args) throws FileNotFoundException,IOException {
		
		
		FileInputStream fs=new FileInputStream("D:\\ScreenShot Folder");
		
		
	}

}
