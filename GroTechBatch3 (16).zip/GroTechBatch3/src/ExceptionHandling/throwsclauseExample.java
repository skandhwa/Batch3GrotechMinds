package ExceptionHandling;

public class throwsclauseExample {

	public static void main(String[] args) throws InterruptedException {
	
		Thread.sleep(50000);
		

	}

}
