package ExceptionHandling;

public class NumberFormatExceptionExample {

	public static void main(String[] args) {
		
		try
		{
		
		//String str="saurabh";
			String k="20";
		int x=Integer.parseInt(k);
		System.out.println(x);
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		int f=20;
		int b=30;
		int c=f+b;
		System.out.println(c);
		

	}

}
