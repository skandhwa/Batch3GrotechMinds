package Constants;

public class Constants {
	
	public static final String TESTDATAPATH= "D:\\TestData0412\\TestData0412.xlsx";

}
