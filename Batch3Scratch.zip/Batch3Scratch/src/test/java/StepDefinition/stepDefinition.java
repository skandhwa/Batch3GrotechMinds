package StepDefinition;

import org.openqa.selenium.WebDriver;

import Pagefactory.LoginScenario;
import Utilities.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition extends BaseClass{
	
	WebDriver driver=BaseClass.initializeDriver();
	LoginScenario obj=new LoginScenario(driver);
	
	
	@Given("User logins into the application")
	public void user_logins_into_the_application() {
		
		System.out.println("User Login is successfull");
		
	    
	}

	@Given("User will enter the {string}")
	public void user_will_enter_the(String Username) {
		
		obj.enterUserID(Username);
		
	   
	}

	@Given("User then enters the {string}")
	public void user_then_enters_the(String Password) throws InterruptedException {
		
		obj.enterUserPassword(Password);
		AddHardcodedWait();
		
		
	   
	}

	@When("User Will click on Login Button")
	public void user_will_click_on_login_button() {
		
		obj.clickOnSubmit();
		
		
	  
	}

	@Then("User Will be navigated to homepage")
	public void user_will_be_navigated_to_homepage() {
		
		System.out.println("Title of the Page is");
		getTitleOfPage();
		
		
	   
	}


}
