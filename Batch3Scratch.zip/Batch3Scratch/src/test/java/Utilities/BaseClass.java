package Utilities;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {
	
	
	public static WebDriver driver;
	
	public static WebDriver initializeDriver() 
	{
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		try {
			driver.get(GetDataFromExcel.getUrl());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver;
	}
	
	public static void getTitleOfPage()
	{
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	public static void AddHardcodedWait() throws InterruptedException
	{
		Thread.sleep(3000);
	}
	
	
	
	
	

}
