package basicConcepts;

public class SumOfAllElements {

	public static void main(String[] args) {
		
		int []a=new int[] {10,3,5,7,2,3,4,5,6,7,8};
		int sum=0;
		
		
		for(int i=0;i<a.length;i++)//i=0,0<4//i=1,1<4//4<4
		{
			sum=sum+a[i];//sum=13+5=18//sum=18+a[3]=18+7=25
		}
		
		System.out.println(sum);
		
		

	}

}
