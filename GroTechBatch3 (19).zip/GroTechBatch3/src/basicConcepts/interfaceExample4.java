package basicConcepts;

interface Bank9
{
	float rateofIntrest();
}

class SBI implements Bank9
{
	public float rateofIntrest()
	{
		return 8.5f;
	}
}
class PNB implements Bank9
{
	public float rateofIntrest()
	{
		return 9.5f;
	}
}

class HDFC implements Bank9
{
	public float rateofIntrest()
	{
		return 10.5f;
	}
}

public class interfaceExample4 {

	public static void main(String[] args) {
		
		Bank9 ref=new SBI();
	System.out.println(ref.rateofIntrest());	
	
	Bank9 ref1=new HDFC();
	System.out.println(ref1.rateofIntrest());	
		

	}

}
