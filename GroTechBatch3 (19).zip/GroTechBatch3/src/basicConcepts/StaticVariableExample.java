package basicConcepts;

class Student5
{
	int rollno;
	String name;
	//String college="IIT Kanpur";
	static String college="IIT Roorke";
	
	Student5(int r,String n)
	{
		rollno=r;
		name=n;
		
	}
	
	void display()
	{
		System.out.println(rollno);
		System.out.println(name);
		System.out.println(college);
		System.out.println();
	}
	
	
	
}
public class StaticVariableExample {

	public static void main(String[] args) {
		
		Student5 obj=new Student5(1234,"Saurabh");
		Student5 obj1=new Student5(3456,"Manoj");
		obj.display();
		obj1.display();
		
		

	}

}
