package basicConcepts;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String s1="Saurabh";
		String s2="saurabh";
		String s3="saurabh";
		String s4="";
		
	boolean flag=	s1.equalsIgnoreCase(s3);
	System.out.println(flag);
	
	
	boolean flag3=s4.isEmpty();
	System.out.println("Is empty ?  "+flag3);
	
	
	
		
		
		
		
	}

}
