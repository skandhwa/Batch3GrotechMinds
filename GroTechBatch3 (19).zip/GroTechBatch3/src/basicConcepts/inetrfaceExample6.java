package basicConcepts;

interface HA
{
	void draw();
	static int square(int y)
	{
		return y*y;
	}
}

class HB implements HA
{
	public void draw()
	{
		System.out.println("I am draw method");
	}
}


public class inetrfaceExample6 {

	public static void main(String[] args) {
		
		
		HA ref=new HB();
		ref.draw();
	System.out.println(HA.square(5));	
		

	}

}
