package basicConcepts;

public class ifElseloopMaximumBwThreeNumbers {

	public static void main(String[] args) {
		
		int a=10;
		int b=50;
		int c=80;
		
		if(a>=b)//10>=50
		{
			if(a>=c)
			{
				System.out.println("a is largest");
			}
			
			else
			{
				System.out.println("c is largest");
			}
		}
		
		else
			
		{
			if(b>=c)///
			{
				System.out.println("b is largest");
			}
			else
			{
				System.out.println("c is largest");
			}
		}
			
		
		
	}

}
