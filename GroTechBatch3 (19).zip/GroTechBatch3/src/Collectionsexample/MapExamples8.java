package Collectionsexample;

import java.util.HashMap;

public class MapExamples8 {

	public static void main(String[] args) {
		
		HashMap <Integer,String>mp=new HashMap<Integer,String>();
		mp.put(1,"Saurabh");
		mp.put(2,"Manish");
		mp.put(3,"Gaurabh");
		mp.put(4,"Rakesh");
		System.out.println("Values of Map are" +mp.values());
		
	System.out.println(mp.get(1));	
		

	}

}
