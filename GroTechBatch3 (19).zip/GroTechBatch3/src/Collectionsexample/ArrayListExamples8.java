package Collectionsexample;

import java.util.ArrayList;

public class ArrayListExamples8 {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(5);
		li.add(9);
		li.add(12);
		li.add(13);
		li.add(50);
		
		ArrayList<Integer> li2=new ArrayList<Integer>();
//		li2.add(5);
//		li2.add(8);
//		li2.add(11);
//		li2.add(16);
//		li2.add(50);
//		
		
		li2.add(5);
		li2.add(9);
		li2.add(12);
		li2.add(13);
		li2.add(50);
		
	boolean flag=	li.containsAll(li2);
	System.out.println(flag);
		

	}

}
