package Collectionsexample;

import java.util.ArrayList;

public class ArrayListMethods9 {

	public static void main(String[] args) {
		
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("Saurabh");
		li.add("Manish");
		li.add("ramesh");
		li.add("Harish");
		
		
		li.replaceAll(e ->e.toUpperCase());
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		
		ArrayList<Integer> li2=new ArrayList<Integer>();
		li2.add(5);
		li2.add(8);
		li2.add(11);
		li2.add(16);
		li2.add(50);
		
li2.replaceAll(f ->f*2);;
		
		for(int z:li2)
		{
			System.out.println(z);
		}

	}

}
