package Collectionsexample;

import java.util.HashSet;
import java.util.Set;

public class SetMethods3 {

	public static void main(String[] args) {
		
		HashSet<String> data1=new HashSet<String>();
		data1.add("Saurabh");
		data1.add("manoj");
		data1.add("Harsh");
		data1.add("Rachin");
		data1.add("Rachin");
		
		Set<String> clonedSet=new HashSet();
		
		clonedSet=(HashSet)data1.clone();
		
		for(String x:clonedSet)
		{
			System.out.println(x);
		}
		
		
		boolean flag=data1.contains("manojK");
		System.out.println(flag);

	}

}
