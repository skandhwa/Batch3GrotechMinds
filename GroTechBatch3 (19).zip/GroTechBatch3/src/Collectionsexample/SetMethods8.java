package Collectionsexample;

import java.util.HashSet;
import java.util.Set;

public class SetMethods8 {

	public static void main(String[] args) {
		
        Set<Integer> s=new HashSet<Integer>();
		
		s.add(23);
		s.add(45);
		s.add(56);
		s.add(67);
		
		 Set<Integer> s2=new HashSet<Integer>();
			
			s2.add(13);
			s2.add(25);
			s2.add(35);
			s2.add(67);
			
			
			s.removeAll(s2);
			
			for(int x:s)
			{
				System.out.println(x);
			}
			
		
		

	}

}
