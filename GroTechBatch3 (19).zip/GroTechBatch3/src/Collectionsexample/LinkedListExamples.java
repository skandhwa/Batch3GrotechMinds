package Collectionsexample;

import java.util.LinkedList;

public class LinkedListExamples {

	public static void main(String[] args) {
		
		LinkedList<String> li=new LinkedList<String>();
		li.add("Samir");
		li.add("rahul");
		li.add("Mukesh");
		li.add("manan");
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		
		

	}

}
