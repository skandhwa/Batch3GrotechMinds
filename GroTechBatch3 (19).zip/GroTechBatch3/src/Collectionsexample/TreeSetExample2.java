package Collectionsexample;

import java.util.TreeSet;

public class TreeSetExample2 {

	public static void main(String[] args) {
		
		TreeSet<String> t1=new TreeSet<String>();
		
		t1.add("A");
		t1.add("B");
		t1.add("C");
		t1.add("D");
		t1.add("E");
		
		
		
		for(String x:t1)
		{
			System.out.println(x);
		}
		
		
		System.out.println("Reverse set is  "+t1.descendingSet());
		
		System.out.println("Head Set is "+t1.headSet("C",true));
		
		System.out.println("Tail Set is "+t1.tailSet("C",true));
		
		
		System.out.println("Sub Set is "+t1.subSet("A",false,"E",true));
		
		
		

	}

}
