package Collectionsexample;

import java.util.HashSet;
import java.util.Set;

public class SettoArray {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("Java");
		s1.add("Python");
		s1.add("C");
		
		for(String x:s1)
		{
			System.out.println(x);
		}
		
		System.out.println("Array Elements are ");
		
		Object[] arr=s1.toArray();
		
		for(Object y:arr)
		{
			System.out.println(y);
		}
		
		
		
		
		

	}

}
