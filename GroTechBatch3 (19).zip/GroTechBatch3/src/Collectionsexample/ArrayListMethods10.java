package Collectionsexample;

import java.util.ArrayList;

public class ArrayListMethods10 {

	public static void main(String[] args) {
		
		ArrayList<Integer> li2=new ArrayList<Integer>();
		li2.add(5);
		li2.add(8);
		li2.add(11);
		li2.add(16);
		li2.add(50);
		
		li2.removeIf(e -> (e%2)!=0);
		
		for(int x:li2)
		{
			System.out.println(x);
		}
		

	}

}
