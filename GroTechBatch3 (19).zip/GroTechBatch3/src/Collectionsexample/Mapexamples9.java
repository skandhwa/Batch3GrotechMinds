package Collectionsexample;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class Mapexamples9 {

	public static void main(String[] args) {
		
		LinkedHashMap<String,Integer> price=new LinkedHashMap<String,Integer>();
		
		price.put("tshirt", 200);
		price.put("Jeans", 300);
		price.put("shoes", 400);
		price.put("kurtas", 500);
		
		System.out.println(price);
		
	int returnedvalue=	price.merge("Jeans",300, (oldValue,newValue) -> (oldValue+newValue));
		
		System.out.println(returnedvalue);
		

	}

}
