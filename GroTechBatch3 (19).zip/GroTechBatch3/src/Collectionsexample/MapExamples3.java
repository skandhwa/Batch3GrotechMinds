package Collectionsexample;

import java.util.HashMap;
import java.util.Map;

public class MapExamples3 {

	public static void main(String[] args) {
		
		Map <Integer,String>mp=new HashMap<Integer,String>();
		mp.put(1,"Saurabh");
		mp.put(2,"Manish");
		mp.put(3,"Gaurabh");
		mp.put(4,"Rakesh");
		
		
		System.out.println(mp);
		
		//mp.clear();
		
		//System.out.println("After clearing elements are "+mp);
		
		
		
		
		

	}

}
