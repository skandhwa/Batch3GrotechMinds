package Collectionsexample;

import java.util.HashMap;
import java.util.Map;

public class FrequencyofString {

	public static void main(String[] args) {
		
		String str="tip top toe top  tip toe";
		
		Map<String,Integer> mp=new HashMap<String,Integer>();
		
		String []words=str.split(" ");
		
		for(String word:words)
		{
			if(mp.containsKey(word))
			{
				mp.put(word, (mp.get(word)+1));
				
				///mp.put(top,(mp.get(top))+1)
				//mp.put(top,2)
			}
			
			else
			{
				mp.put(word,1);
			}
		}
		
		for(Map.Entry entry:mp.entrySet())
		{
			System.out.println(entry.getKey() +"  "+entry.getValue());
		}
		
		

	}

}
