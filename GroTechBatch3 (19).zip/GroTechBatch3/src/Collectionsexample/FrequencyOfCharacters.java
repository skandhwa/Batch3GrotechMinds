package Collectionsexample;

import java.util.HashMap;
import java.util.Map;

public class FrequencyOfCharacters {

	public static void main(String[] args) {
		
		String str= "Ramam";
		HashMap<Character,Integer> mp=new HashMap<Character,Integer>();
		char []strArray=str.toCharArray();
		
		for(char c:strArray)
		{
			if(mp.containsKey(c))
			{
				mp.put(c, (mp.get(c))+1);
			}
			else
				mp.put(c,1);
		}
		
		System.out.println("The corresponding key value pair is ");
		
		for(Map.Entry entry:mp.entrySet())
		{
			
			System.out.println(entry.getKey()+" "+ entry.getValue());
		}
		
		
		
		
		
		

	}

}
