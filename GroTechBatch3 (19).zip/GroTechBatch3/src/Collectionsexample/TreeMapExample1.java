package Collectionsexample;

import java.util.TreeMap;

public class TreeMapExample1 {

	public static void main(String[] args) {
		
		TreeMap<String,Integer> mp=new TreeMap<String,Integer>();
		mp.put("Two",2);
		mp.put("Taw",3);
		mp.put("Tabw",6);
		mp.put("abw",9);
		
		System.out.println(mp);
		
	}

}
