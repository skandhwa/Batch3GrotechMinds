package basicConcepts;

public class LargestBwTwoNumbers {

	public static void main(String[] args) {
		
		int a=15;
		int b=20;
		int c=30;
		if(a>b )
		{
			System.out.println("a is largest");
		}
		
		else
		{
			System.out.println("b is largest");
		}
		

	}

}
