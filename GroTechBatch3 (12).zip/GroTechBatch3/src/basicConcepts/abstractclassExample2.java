package basicConcepts;

abstract class Shape
{
	abstract void draw();
}

class Square extends Shape
{
	void draw()
	{
		System.out.println("Hello I am square");
	}
}

class Hexagon extends Shape
{
	void draw()
	{
		System.out.println("Hello I am Hexagon");
	}
}
public class abstractclassExample2 {

	public static void main(String[] args) {
		
		Shape obj=new Square();
		obj.draw();
		
		Shape obj1=new Hexagon();
		obj1.draw();
		
		///WebDriver driver=new ChromeDriver();
		
		
		

	}

}
