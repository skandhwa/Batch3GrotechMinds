package basicConcepts;

public class whileLoopExamples {

	public static void main(String[] args) {
		
		int x=15;///initialization
		
		int a=7;
		int b=7/10;
		System.out.println(b);
		System.out.println();
		
		while(x<18)////condition checking
		{
			System.out.println(x);//15//16//17
			x++;///increment/decrement
			
			
		}
		

	}

}
