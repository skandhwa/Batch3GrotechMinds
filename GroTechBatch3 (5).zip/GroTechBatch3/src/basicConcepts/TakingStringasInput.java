package basicConcepts;

import java.util.Scanner;

public class TakingStringasInput {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
		String name=sc.next();
		
	int x=	name.length();
	
	System.out.println("The String entered is  " +name);
	System.out.println("The length of String  " +x);
		
		
		
		
		
		
		

	}

}
