package basicConcepts;

public class VariablesinJava {
	
	    int x=40;
	
	
	void add()
	{
		int a=20;
		int b=30;
		int c=a+b+x;
		System.out.println(c);		
		System.out.println("I am print statement");
	}
	
	void Sub()
	{
		int a=20;
		int b=30;
		int c=a+b-x;
		System.out.println(c);		
		System.out.println("I am print statement");
	}
	
	
	int multipication()
	{
		int p=20;
		int q=30;
		return p*q;
		
	}
	
	public static void main(String[] args) 
	
	{
		VariablesinJava obj=new VariablesinJava();
		obj.add();
		obj.Sub();
		System.out.println	(obj.multipication());

	}

}
