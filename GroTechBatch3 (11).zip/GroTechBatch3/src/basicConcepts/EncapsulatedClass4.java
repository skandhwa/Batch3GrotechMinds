package basicConcepts;

public class EncapsulatedClass4 {

	public static void main(String[] args) {
		
		
		EncapsulatedReadOnlyClass obj=new EncapsulatedReadOnlyClass();
		//System.out.println	(obj.getName());
		System.out.println	(obj.getSalary());
		

	}

}
