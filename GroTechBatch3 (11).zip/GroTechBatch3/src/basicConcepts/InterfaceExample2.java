package basicConcepts;

interface Shape2
{
	void draw();
	
	
}

class Circle implements Shape2
{
	
	public void draw()
	{
		System.out.println("Drawing Circle");
		
	}
}

class Rectangle implements Shape2
{
	public void draw()
	{
		System.out.println("Drawing Rectangle");
	}
}
public class InterfaceExample2 {

	public static void main(String[] args) {
		
		Shape2 ref=new Circle();
		ref.draw();
		
		Shape2 ref1=new Rectangle();
		ref1.draw();
		
		

	}

}
