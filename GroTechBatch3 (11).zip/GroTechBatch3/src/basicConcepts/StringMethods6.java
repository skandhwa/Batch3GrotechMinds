package basicConcepts;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="India is a vast country";
		
		int x=str.indexOf("is");
		System.out.println(x);
		
	}

}
