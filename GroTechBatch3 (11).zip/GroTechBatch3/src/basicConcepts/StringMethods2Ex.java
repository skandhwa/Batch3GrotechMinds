package basicConcepts;

public class StringMethods2Ex {

	public static void main(String[] args) {
		
		String str="india is vast";
	str=str.substring(4);
		System.out.println(str);
		
		
		
//		String str1=str.substring(6,11);
//		System.out.println(str1);
//		
//		
//	boolean flag=	str.contains("VAST");
//	System.out.println(flag);

	}

}
