package basicConcepts;

public class JaggedArrayEx {

	public static void main(String[] args) {
		
		int a[][]=new int[4][0];
		
		

	}

}
