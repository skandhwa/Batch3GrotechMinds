package basicConcepts;

import java.util.Arrays;

public class ArrayMethods {

	public static void main(String[] args) {
		
		int []a=new int[] {112,324,516,78};
		int []b=new int[] {112,324,516,78};
		
		int x=a.length;
		System.out.println(x);
		
		Arrays.sort(a);
		
		for(int y:a)
		{
			System.out.println(y);
		}
		
		System.out.println();
		System.out.println();
	
		
	int flag=	Arrays.compare(a,b);
	System.out.println("The comparision is  "+flag);
		
		
		

	}

}
