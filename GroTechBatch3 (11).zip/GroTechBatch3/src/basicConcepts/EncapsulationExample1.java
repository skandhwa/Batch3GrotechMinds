package basicConcepts;

public class EncapsulationExample1 {

	public static void main(String[] args) {
		
		EncapsulatedClassExample s=new EncapsulatedClassExample();
		s.setName("Saurabh");
		
		System.out.println(s.getName());
		

	}

}
