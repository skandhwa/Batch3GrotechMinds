package basicConcepts;

import java.util.Scanner;

public class MenuDrivenTakingInputFromUSer {

	public static void main(String[] args) {
		
		int a,b,c;
		int choice;
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter value 1 for Addition");
			System.out.println("Enter value 2 for Subtraction");
			System.out.println("Enter value 3 for Multiplication");
			System.out.println("Enter value 4 for Division");
			System.out.println("Enter 5 to Quit \n\n");
			
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				
				System.out.println("Enter first number");
				a=sc.nextInt();
				System.out.println("Enter second number");
				b=sc.nextInt();
			    c=a+b;
			    System.out.println("The addition is  "+c);
			    break;
			    
			    
            case 2:
				
				System.out.println("Enter first number");
				a=sc.nextInt();
				System.out.println("Enter second number");
				b=sc.nextInt();
			    c=a-b;
			    System.out.println("The difference is  "+c);
			    break; 
             case 3:
				
				System.out.println("Enter first number");
				a=sc.nextInt();
				System.out.println("Enter second number");
				b=sc.nextInt();
			    c=a*b;
			    System.out.println("The product is  "+c);
			    break;   
			    
			    
             case 4:
 				
 				System.out.println("Enter first number");
 				a=sc.nextInt();
 				System.out.println("Enter second number");
 				b=sc.nextInt();
 			    c=a/b;
 			    System.out.println("The division is  "+c);
 			    break;
 			    
             case 5:
            	 System.exit(0);
            	 
            	 
            default:
            	System.out.println("Invalid choice");
            	 
			
			
			}
			
			
			
			
		}
		
		
		

	}

}
