package basicConcepts;

class CR
{
	CR()
	{
		System.out.println("Hello");
	}
	
	CR(int x)
	{
		this();
		System.out.println(x);
	}
	
}


public class thisKeywordExample {

	public static void main(String[] args) {
		
		
		CR obj=new CR(10);
		

	}

}
