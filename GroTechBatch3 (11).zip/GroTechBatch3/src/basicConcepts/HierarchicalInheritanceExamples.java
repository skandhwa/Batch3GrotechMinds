package basicConcepts;

class AY
{
	int multiply(int x,int y)//5*4//5.0f*4
	{
		return x*y;//20///20.0
	}
	
	float add(float x,int y)//5*4//5.0f*4
	{
		return x+y;//20///20.0
	}
	
	double sub(int x,int y)
	{
		return x-y;
	}
}

class BY extends AY
{
	void display()
	{
		System.out.println("Hello");
	}
}


class CY extends AY
{
	void test()
	{
		System.out.println("i am test");
	}
}

public class HierarchicalInheritanceExamples {

	public static void main(String[] args) {
		
		CY obj=new CY();
		obj.multiply(23, 10);
		BY obj1=new BY();
		obj1.add(23.5f, 65);
		
		
		

	}

}
