package basicConcepts;

abstract class EA
{
	public static void display()
	{
		System.out.println("Hello");
	}
	
	public abstract static void msg();
	
}



public class AbstractClassStatic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
