package basicConcepts;

public class ArrayExample2 {

	public static void main(String[] args) {
		
		int a[]= {12,45,67,89,95};
		
		for()
		
		

	}

}
