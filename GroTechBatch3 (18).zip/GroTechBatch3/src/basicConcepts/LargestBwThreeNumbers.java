package basicConcepts;

public class LargestBwThreeNumbers {

	public static void main(String[] args) {
		
		int a=15,b=20,c=12;
		
		
		
		int max= (a>b) ? (a>c?a:c) : (b>c ?b:c);
		
		///15>20//20>12
		
		
		///Relational Operators === > < >= <= == !
		
		System.out.println(max);
		
		int z=10;
		 z=+5;//z=z+5
		 
		 int t=12;
		 t*=4;//t=t*4=12*4
		 System.out.println(t);
		 
		 int p=100;
		 
		 p/=20;///p=p/20=100/20=5
		 
		 System.out.println(p);
		
		
		
		
		
	}

}
