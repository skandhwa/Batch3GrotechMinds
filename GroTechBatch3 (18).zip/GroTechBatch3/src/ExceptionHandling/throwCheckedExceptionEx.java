package ExceptionHandling;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class throwCheckedExceptionEx {
	
	public static void method() throws FileNotFoundException
	{
		FileReader f=new FileReader("D:\\ScreenShot Folder\\TestGrotech.png");
		BufferedReader br=new BufferedReader(f);
		throw new FileNotFoundException();
		
		
		
	}
	
	

	public static void main(String[] args) throws FileNotFoundException  {
		
		
			throwCheckedExceptionEx.method();
		
		
			
			
	
		
		System.out.println("Rest of the code");
		
		
		
		
		

	}

}
