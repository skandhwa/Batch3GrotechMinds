package Collectionsexample;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueExamples {

	public static void main(String[] args) {
		
		Queue<String> q=new PriorityQueue<String>();
		
		q.add("Saurabh");
		q.add("Harish");
		q.add("Ramesh");
		q.add("Jai");
		
		Iterator itr=q.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println();
		q.remove();
		Iterator itr1=q.iterator();
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		}
		System.out.println();
		System.out.println();
		q.remove();
		
		Iterator itr2=q.iterator();
		while(itr2.hasNext())
		{
			System.out.println(itr2.next());
		}
		
		
	
		

	}

}
