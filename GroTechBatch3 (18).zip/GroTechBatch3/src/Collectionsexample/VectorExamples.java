package Collectionsexample;

import java.util.Vector;

public class VectorExamples {

	public static void main(String[] args) {
        
		Vector<Integer> vi=new Vector<Integer>();
		vi.add(45);
		vi.add(56);
		vi.add(78);
		
		for(int x:vi)
		{
			System.out.println(x);
		}
		
		
		


	}

}
