package Collectionsexample;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class MapExamples5 {

	public static void main(String[] args) {
		
		
		HashMap<String,String> mp=new LinkedHashMap<String,String>();
		mp.put("A","Saurabh");
		mp.put("B","Manish");
		mp.put("C","Gaurabh");
		mp.put("D","Rakesh");
		mp.put(null,"Hitesh");
		mp.put(null,null);
		mp.put("F",null);
		mp.put("G",null);
		System.out.println("The orginal Map is "+mp);
		
		
		
		
		
		

	}

}
