package Collectionsexample;

import java.util.HashMap;

public class MapExamples6 {

	public static void main(String[] args) {
		
		HashMap <Integer,String>mp=new HashMap<Integer,String>();
		mp.put(1,"Saurabh");
		mp.put(2,"Manish");
		mp.put(3,"Gaurabh");
		mp.put(4,"Rakesh");
		mp.putIfAbsent(4, "Harish");
		
		mp.replace(4, "Hari");
		
		mp.remove(2);
		
	boolean flag=	mp.containsKey(8);
	System.out.println(flag);
	boolean flag2=	mp.containsValue("Rakesh");
	System.out.println("Does this contains value ?" +flag2);
		
		
		
		System.out.println("The orginal Map is "+mp);
		
		

	}

}
