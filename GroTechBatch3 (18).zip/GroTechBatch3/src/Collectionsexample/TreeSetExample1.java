package Collectionsexample;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetExample1 {

	public static void main(String[] args) {
		
		TreeSet<Integer> t1=new TreeSet<Integer>();
		t1.add(4);
		t1.add(23);
		t1.add(15);
		t1.add(2);
		
//		 for(int x:t1)
//		 {
//			 System.out.println(x);
//		 }
		
		
		Iterator itr=t1.descendingIterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println("The minimum value in tree set is  "+t1.pollFirst());
		System.out.println("The maximum value in tree set is  "+t1.pollLast());
		

	}

}
