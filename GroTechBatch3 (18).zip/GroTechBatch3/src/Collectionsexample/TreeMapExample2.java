package Collectionsexample;

import java.util.TreeMap;

public class TreeMapExample2 {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();
		mp.put(104, "Ramesh");
		mp.put(101, "Mahesh");
		mp.put(99, "Hitesh");
		mp.put(108, "sarwesh");
		System.out.println(mp.descendingMap());
		
		
		System.out.println("headmap"  +mp.headMap(104,true));
		
		System.out.println("TailMap"  +mp.tailMap(104,true));
		
		System.out.println("SubMap is "+mp.subMap(99,false, 108,true));
		

	}

}
