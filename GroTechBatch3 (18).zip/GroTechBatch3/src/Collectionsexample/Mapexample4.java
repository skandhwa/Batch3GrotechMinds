package Collectionsexample;

import java.util.HashMap;
import java.util.Map;

public class Mapexample4 {
	
	public static void main(String[] args) {
		
		HashMap <Integer,String>mp=new HashMap<Integer,String>();
		mp.put(1,"Saurabh");
		mp.put(2,"Manish");
		mp.put(3,"Gaurabh");
		mp.put(4,"Rakesh");
		System.out.println("The orginal Map is "+mp);
		
		System.out.println("The Size of Hash Map is "+mp.size());
		
		
		HashMap <Integer,String>cloneMap=(HashMap <Integer,String>)mp.clone();
		
		System.out.println("The Cloned Elements of Map are ");
		System.out.println(cloneMap);
		
		
	}
	}


