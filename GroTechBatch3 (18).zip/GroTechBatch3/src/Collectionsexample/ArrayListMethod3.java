package Collectionsexample;

import java.util.ArrayList;
import java.util.Comparator;

public class ArrayListMethod3 {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(67);
		li.add(54);
		li.add(42);
		li.add(89);
		li.add(19);
		li.add(29);
		li.add(49);
		
		li.sort(Comparator.reverseOrder());
		System.out.println("Elements is descending order is ");
		System.out.println(li);
		
		
		
		System.out.println("The New Cloned array list is as below");
		
		ArrayList<Integer> li2=(ArrayList<Integer>)li.clone();
		
		for(int x:li2)
		{
			System.out.println(x);
		}
		
		
	boolean flag=	li2.contains(99);
	System.out.println(flag);
	
	int z=li2.get(3);
	System.out.println(z);
	
	int p=li2.size();
	System.out.println("The Size of Array List is  "+p);
	
	int u=li2.indexOf(899);
	System.out.println("Index of 899 is  "+u);
		
	
    System.out.println(li2.subList(2, 7));	
    
   li2.sort(Comparator.naturalOrder()); 
   
   System.out.println("Elements of Array list in sorted order is  ");
   System.out.println(li2);
   
    
		
		

	}

}
