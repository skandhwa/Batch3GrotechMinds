package Collectionsexample;

import java.util.HashMap;
import java.util.Map;

public class FrequencyofArray {

	public static void main(String[] args) {
		
		int a[]= {10,20,30,10,20,30,40,50,60,10,20,40,60,50};
		int n=a.length;
		
		Map<Integer,Integer> mp=new HashMap<Integer,Integer>();
		
		for(int i=0;i<n;i++)//i=1
		{
			if(mp.containsKey(a[i]))//a[6]
			{
				mp.put(a[i],mp.get(a[i])+1);//mp.put(10,(mp.get(10))+1
				
				///mp.put(20,(mp.get(20))+1)//mp.put(20,2)
				
				//mp.put(30,(mp.get(30)+1)
				
				//mp.put(40,1+1)
				//mp.put(40,2)
				
			}
			
			else
			{
				mp.put(a[i],1);//mp.put(10,1)
			}
		}
		
		
		for(Map.Entry entry:mp.entrySet())
		{
			System.out.println(entry.getKey() +" "+entry.getValue());
		}
		
		
		

	}

}
