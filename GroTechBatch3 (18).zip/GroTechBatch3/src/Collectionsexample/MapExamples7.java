package Collectionsexample;

import java.util.HashMap;

public class MapExamples7 {

	public static void main(String[] args) {
		
		//HashMap <Integer,String>mp=new HashMap<Integer,String>();
//		mp.put(1,"Saurabh");
//		mp.put(2,"Manish");
//		mp.put(3,"Gaurabh");
//		mp.put(4,"Rakesh");
		
		HashMap <Integer,Integer>mp=new HashMap<Integer,Integer>();
		
		mp.put(1,4);
		mp.put(2,14);
		mp.put(3,24);
		mp.put(5,34);
		mp.put(4,44);
		
		
		
		System.out.println("Before Modification values are "+mp);
		
	//	mp.replaceAll((key,value) -> value.toUpperCase());
		
		mp.replaceAll((key,value) -> key * key);;
		
		System.out.println("After Modification values are "+mp);
		

	}

}
