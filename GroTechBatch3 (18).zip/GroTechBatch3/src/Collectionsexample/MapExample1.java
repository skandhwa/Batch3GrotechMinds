package Collectionsexample;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapExample1 {

	public static void main(String[] args) {
		
		
		Map <Integer,String>mp=new HashMap<Integer,String>();
		mp.put(1,"Saurabh");
		mp.put(2,"Manish");
		mp.put(3,"Gaurabh");
		mp.put(4,"Rakesh");
		
		//System.out.println(mp);
		
	Set s1=	mp.entrySet();
	
	Iterator itr=s1.iterator();
	while(itr.hasNext())
	{
		Map.Entry entry=(Map.Entry)itr.next();
		System.out.print(entry.getKey()+" ");
		System.out.println(entry.getValue());
		
	}
	
	
	
		
		for(Map.Entry m:mp.entrySet())
		{
			System.out.print(m.getKey()+" ");
			System.out.println(m.getValue()+" ");
		
		
	}
	
	
	
		
		

	}

}
