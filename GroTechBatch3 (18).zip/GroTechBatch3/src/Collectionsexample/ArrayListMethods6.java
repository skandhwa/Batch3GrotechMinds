package Collectionsexample;

import java.util.ArrayList;

public class ArrayListMethods6 {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(5);
		li.add(9);
		li.add(12);
		li.add(13);
		li.add(50);
		
		ArrayList<Integer> li2=new ArrayList<Integer>();
		li2.add(5);
		li2.add(8);
		li2.add(11);
		li2.add(16);
		li2.add(50);
		
		li2.retainAll(li);
		
		for(int x:li2)
		{
			System.out.println(x);
		}
		
		System.out.println();
		System.out.println();
		
	boolean flag=	li.containsAll(li2);
	
	System.out.println(flag);
		for(int y:li)
		{
			System.out.println(y);
		}
		

	}

}
