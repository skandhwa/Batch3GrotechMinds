package AccessModifierDemo;

public class DefaultExample3 {

	public static void main(String[] args) {
		
		DZA obj=new DZA();
		
		

	}

}
