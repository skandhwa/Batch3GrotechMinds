package basicConcepts;

public class DefaultExample2 {

	public static void main(String[] args) {
		
		DZA obj=new DZA();
		obj.display();
		
		
		

	}

}
