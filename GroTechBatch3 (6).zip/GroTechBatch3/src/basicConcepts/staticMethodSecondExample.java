package basicConcepts;

class calculation
{
	static int cube(int x)
	{
		return x*x*x;
	}
}



public class staticMethodSecondExample {

	public static void main(String[] args) {
		
	int result=	calculation.cube(5);
	System.out.println(result);
		
		

	}

}
