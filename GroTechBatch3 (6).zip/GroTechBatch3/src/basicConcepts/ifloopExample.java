package basicConcepts;

public class ifloopExample {

	public static void main(String[] args) {
		
		int x=6;
		if(x>5)//10>5
		{
			if(x>=2 && x<=8)//10>=2,,,10<=4
			{
				System.out.println("I am between 2 and 7");
			}
			
		}

	}

}
