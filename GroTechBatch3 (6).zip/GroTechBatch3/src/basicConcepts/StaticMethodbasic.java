package basicConcepts;

class Animal8
{
	static void display()
	{
		System.out.println("hello");
	}
	
	int add(int x,int y)
	{
		return x+y;
	}
}
public class StaticMethodbasic {

	public static void main(String[] args) {
		
		Animal8.display();
		
//		Animal8 obj=new Animal8();
//		obj.display();
//	System.out.println(obj.add(23, 56));	
		

	}

}
