package basicConcepts;

class Pen1
{
	String brand="Reynolds";
}

class Pencil extends Pen1
{
	String brand="Natraj";
	void display()
	{
		System.out.println("The brand of pencil is "+brand);
		System.out.println("The brand of pen is "+super.brand);
	}
	
}
public class superKeywordExample1 {

	public static void main(String[] args) {
		
		Pencil obj=new Pencil();
		obj.display();

	}

}
