package basicConcepts;

abstract class Car1
{
	int z=40;
	Car1()
	{
		System.out.println("Hello");
	}
	
	int Car(int x,int y)
	{
		return x+y;
	}
	
	 void display()
	{
		System.out.println("I am display method");
	}
	 abstract void test();
	
	
	
	
}
class Bike extends Car1
{

	void test() 
	{
		System.out.println("I am test method");
		int z=20;
		System.out.println("I am of Bike class  "+z);
		System.out.println("I am of Car class  "+super.z);
		
		
	}
	
}
public class AbstractClasswithConstructor {

	public static void main(String[] args) {
		
		Car1 obj=new Bike();
	System.out.println(obj.Car(12, 14));	
		obj.display();
		obj.test();
		

	}

}
