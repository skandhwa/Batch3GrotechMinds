package Utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import Constant.constant;


public class CommonFunctions {
	
	
//	public  static void takescreenshot() throws IOException
//	{
//		
//		TakesScreenshot Srcshot=(TakesScreenshot)(driver);
//		File SrcFile=Srcshot.getScreenshotAs(OutputType.FILE);
//		File DestFile=new File(constant.SCREENSHOTPATH);
//		try {
//			FileUtils.copyFile(SrcFile, DestFile);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	
//		
//	}

}
