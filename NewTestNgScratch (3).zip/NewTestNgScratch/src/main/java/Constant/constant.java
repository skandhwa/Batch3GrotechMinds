package Constant;

public class constant {
	
	public static final String TESTDATAPATH="E:\\TestData0108.xlsx";
    public static final String PROPERTYFILEPATH="E:\\EclipseWorkspace\\NewTestNgScratch\\src\\main\\java\\Constant\\GlobalData.properties";
    
}
