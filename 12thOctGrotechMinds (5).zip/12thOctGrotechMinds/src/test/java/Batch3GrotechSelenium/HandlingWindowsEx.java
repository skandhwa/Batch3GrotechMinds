package Batch3GrotechSelenium;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindowsEx {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		
	    String WindowID=	driver.getWindowHandle();
		System.out.println(WindowID);
		
	WebElement ele=	driver.findElement(By.xpath("(//button[@class='btn btn-info'])[1]"));
		ele.click();
		
		Set<String> S1=driver.getWindowHandles();
		System.out.println(S1);
		
		
		Iterator<String> I1=S1.iterator();
		while(I1.hasNext())
		{
		String childwindow=	I1.next();
		if(!WindowID.equals(childwindow))
		{
			String title_child_window=driver.switchTo().window(childwindow).getTitle();
			System.out.println(title_child_window);
			Thread.sleep(3000);
			driver.close();
			
			
		}
		}
	
		
		driver.switchTo().window(WindowID);
		String URL=	driver.getCurrentUrl();
		System.out.println(URL);
		
		
		}
		
		
		
		
		
	}


