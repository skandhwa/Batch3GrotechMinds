package Batch3GrotechSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetSizeExample {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
	WebElement ele=	driver.findElement(By.xpath("//input[@id='vfb-5']"));
		Dimension d=ele.getSize();
		
		int x=d.height;
		System.out.println("Height of element is "+x);
		
		int y=d.width;
		System.out.println("Width of element is "+y);
		
		Point p=ele.getLocation();
		System.out.println("x cordinates are "+p.x);
		System.out.println("y cordinates are "+p.y);
		
		
		

	}

}
