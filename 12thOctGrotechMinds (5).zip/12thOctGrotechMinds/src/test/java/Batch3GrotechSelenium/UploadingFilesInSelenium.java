package Batch3GrotechSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UploadingFilesInSelenium {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		WebElement ele=driver.findElement(By.xpath("//input[@id='photo']"));
		ele.sendKeys("C:\\Users\\saura\\OneDrive\\Desktop\\GroTechMind Demo\\Notes.txt");
		

	}

}
