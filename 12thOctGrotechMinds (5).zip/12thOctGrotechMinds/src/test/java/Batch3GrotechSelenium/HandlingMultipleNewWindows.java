package Batch3GrotechSelenium;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingMultipleNewWindows {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		
		String WindowID=driver.getWindowHandle();
		System.out.println(WindowID);
		
		
		driver.findElement(By.xpath("//a[@href='#Seperate']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='click']")).click();
		
		Set<String> WindowIds=driver.getWindowHandles();
		System.out.println(WindowIds);
		
		
		
		
		
		
		
	}

}
