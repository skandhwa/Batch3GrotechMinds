package Batch3GrotechSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HighlightValue {

	public static void main(String[] args) {
		

		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		WebElement ele=driver.findElement(By.xpath("//input[@id='vfb-5']"));
		//driver.findElement(By.xpath("//input[@id='vfb-5']")).sendKeys("saurabh");
        
		WebElement ele2=driver.findElement(By.xpath("(//a[text()='Home'])[2]"));
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].style.border='5px solid yellow'",ele);
		js.executeScript("arguments[0].click()",ele2);
		
	String title=	js.executeScript( "return document.title").toString();
	System.out.println(title);
		
	}

}
