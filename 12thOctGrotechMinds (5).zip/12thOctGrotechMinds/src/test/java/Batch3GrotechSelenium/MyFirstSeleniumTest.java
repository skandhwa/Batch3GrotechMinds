package Batch3GrotechSelenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MyFirstSeleniumTest {

	public static void main(String[] args) {
		
		///Earlier 
		//WebDriverManager.chromeDriver.setup();
		
		//System.setProperty("C://chromedriver.exe", webdriver.chr)
		
		WebDriver driver=new ChromeDriver();
//		driver.get("https://www.google.com");
		
//		WebDriver dr1=new FirefoxDriver();
//		dr1.get("https://www.google.com");

		
		WebDriver dr2=new EdgeDriver();
		dr2.get("https://www.google.com");
		

	}

}
