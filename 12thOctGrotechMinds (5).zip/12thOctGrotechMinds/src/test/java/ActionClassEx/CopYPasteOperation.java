package ActionClassEx;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CopYPasteOperation {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		
		
		driver.get("https://demoqa.com/text-box");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='userName']")).sendKeys("Saurabh");
		driver.findElement(By.xpath("//input[@id='userEmail']")).sendKeys("abc@gmail.com");
		
		driver.findElement(By.xpath("//textarea[@id='currentAddress']")).sendKeys("Shantipally Tollygunge Kolkata");
		
		Actions act=new Actions(driver);
		
		//Select the content
		act.keyDown(Keys.CONTROL);
		act.sendKeys("a");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		Thread.sleep(3000);
		
		//copy the entire content
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("c");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		Thread.sleep(3000);
		///press tab button
		
		act.keyDown(Keys.TAB);
		act.build().perform();
		//Thread.sleep(3000);
		
		
		///paste the content
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("v");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		Thread.sleep(3000);

	}

}
