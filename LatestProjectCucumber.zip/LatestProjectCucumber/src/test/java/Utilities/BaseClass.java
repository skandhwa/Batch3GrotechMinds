package Utilities;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {
	
	
	public static WebDriver driver;
	
	public static WebDriver initializeDriver() throws IOException
	{
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(GetDataFromExcel.getUrl());
		return driver;
	}
	
	
	

}
