package basicConcepts;

class Animal
{
	String colour="red";
	int number=40;
	void structure()
	{
		System.out.println("Some Animal are having 4 legs");
	}
}

class Dog extends Animal
{
	String colour="black";
	void bark()
	{
		System.out.println("Dog barks!!!!");
	}
	void eat()
	{
		System.out.println("Dog eats");
	}
	void structure()
	{
		System.out.println("Dog is having 4 legs");
	}
	void character()
	{
		bark();
		eat();
		structure();
		super.structure();
		System.out.println(colour);
		System.out.println(super.colour);
		System.out.println(number);
		
	}
	
}
public class SuperExample2 {

	public static void main(String[] args) {
		
		Dog obj=new Dog();
		obj.character();

	}

}
