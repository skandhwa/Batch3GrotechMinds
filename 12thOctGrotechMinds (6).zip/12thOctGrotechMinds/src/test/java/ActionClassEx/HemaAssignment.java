package ActionClassEx;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HemaAssignment {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		String mwhid = driver.getWindowHandle();
		Thread.sleep(5000);
		WebElement osmwt=driver.findElement(By.xpath("//a[@href='#Multiple']"));
		osmwt.click();
		WebElement mwclick= driver.findElement(By.xpath("(//button[@class='btn btn-info'])[2]"));
		mwclick.click();
		Set<String> whs = driver.getWindowHandles();
		Iterator<String> i = whs.iterator();
		while(i.hasNext()) {
		  String nwhid= i.next();
		  if(!mwhid.equals(nwhid)) {
			 String title= driver.switchTo().window(nwhid).getTitle();
			 System.out.println("The title of the page is "+ title);
			 driver.close();  
		  }
		}
		driver.switchTo().window(mwhid);
		String mtitle = driver.getTitle();
		System.out.println(mtitle);
		String Url = driver.getCurrentUrl();
		System.out.println(Url);


	}

}
