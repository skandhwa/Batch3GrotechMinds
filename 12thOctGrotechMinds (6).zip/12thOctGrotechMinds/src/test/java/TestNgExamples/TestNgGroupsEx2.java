package TestNgExamples;

import org.testng.annotations.Test;

public class TestNgGroupsEx2 {
	
	@Test(groups = {"regression"})
	public void Test3()
	{
		
		System.out.println("I am new Test1 Regression");
	}
	
	@Test(groups= {"sanity"})
	public void Test4()
	{
		System.out.println("I am new Test2 Sanity");
	}

}
