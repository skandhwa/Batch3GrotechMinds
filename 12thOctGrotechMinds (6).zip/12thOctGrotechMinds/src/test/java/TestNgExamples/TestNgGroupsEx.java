package TestNgExamples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgGroupsEx {
	
	
	@Test(groups = {"regression"})
	public void Test1()
	{
		
		System.out.println("I am Test1 Regression");
	}
	
	@Test(groups= {"sanity"})
	public void Test2()
	{
		System.out.println("I am Test2 Sanity");
	}
	
	@Test(groups= {"regression"})
	public void Test3()
	{
		System.out.println("I am Test3 regression");
	}
	
	
	@Test(groups= {"smoke"})
	public void Test4()
	{
		System.out.println("I am Test4 smoke");
	}
	
	
	
	@Test(groups= {"smoke"})
	public void Test5()
	{
		System.out.println("I am Test5 smoke");
	}
	
	
	@Test(groups= {"sanity"})
	public void Test6()
	{
		System.out.println("I am Test6 Sanity");
	}
	
	
	
	
	

}
