package TestNgExamples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNgAssertionExample {
	
	@Test
	public void display()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	String title=	driver.getTitle();
	String ActualTitle="Google";
	Assert.assertEquals(title,ActualTitle);
	System.out.println("My Test Case Got Passed");
	
	boolean flag=false;
	
//	Assert.assertTrue(flag);
//	System.out.println("My Assertions are true");
	
	Assert.assertFalse(flag);
	System.out.println("My Assertions are true");
	
	Assert.assertNotEquals(2,5);
	System.out.println("My Assertions are passed");
	
	

	
	}
	

}
