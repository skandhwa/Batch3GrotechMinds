package TestNgExamples;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FirstExample {

	@AfterTest
	public void A()
	{
		System.out.println("I am after test");//6
	}
	
	@AfterMethod
	public void B()
	{
		System.out.println("I am after Method");//5
	}
	
	@BeforeClass
	public void C()
	{
		System.out.println("I am before test");//2
	}
	
	
	@BeforeMethod
	public void D()
	{
		System.out.println("I am before method");//3
	}
		@Test
	public void E()
	{
		System.out.println("I am Test");//4
	}
	
	@BeforeSuite
	public void F()
	{
		System.out.println("I am Before Suite");//1
	}
	
	
}
