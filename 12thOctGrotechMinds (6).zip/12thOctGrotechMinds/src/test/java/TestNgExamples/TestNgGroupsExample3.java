package TestNgExamples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestNgGroupsExample3 {
	
	@Test(groups= {"sanityA"})
	public void start()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	}
	
	@Test(groups= {"sanityB"})
	public void test1()
	{
		WebDriver driver1=new FirefoxDriver();
		driver1.get("https://www.google.com");
	}
	
	@Test(groups= {"sanityC"})
	public void test3()
	{
		WebDriver driver2=new EdgeDriver();
		driver2.get("https://www.google.com");
	}

}
