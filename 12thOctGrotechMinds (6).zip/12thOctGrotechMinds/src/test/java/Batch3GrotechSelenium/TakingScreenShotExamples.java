package Batch3GrotechSelenium;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class TakingScreenShotExamples {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		
		
		TakesScreenshot srcshot=(TakesScreenshot)driver;
		
	File srcFile=	srcshot.getScreenshotAs(OutputType.FILE);
	File DestFile=new File("D:\\ScreenShot Folder\\"+Math.random()+"test8thNovember.jpg");
	FileUtils.copyFile(srcFile, DestFile);
	
	System.out.println("Screenshot captured");
	

	}

}
