package Batch3GrotechSelenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDynamicWebtables {

	public static void main(String[] args) {

          
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/saura/Downloads/WebTable.html");
		driver.manage().window().maximize();
		
//		String before_Xpath="//table/tbody/tr[";
//		String after_Xpath="]/td[2]";
//		
//	List rows=	driver.findElements(By.xpath("//table/tbody/tr"));
//	int rowsize=rows.size();
//	System.out.println(rowsize);
//	
//	for(int i=2;i<rowsize;i++)
//	{
//		
//	WebElement ele=	driver.findElement(By.xpath(before_Xpath+i+after_Xpath));
//	String name=ele.getText();
//	System.out.println(name);
//	if(name.contains("Will"))
//	{
//		driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[1]/input")).click();
//		
//	}
//	
//		
//	}
	
		
		
	driver.findElement(By.xpath("//td[contains(text(),'Jessica')]//preceding-sibling::td//input[@type='checkbox']")).click();
	
	
		
		
		
		

	}

}
