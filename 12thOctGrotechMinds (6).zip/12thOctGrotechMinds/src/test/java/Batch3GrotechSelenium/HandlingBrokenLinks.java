package Batch3GrotechSelenium;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingBrokenLinks {

	public static void main(String[] args) throws MalformedURLException, IOException {
	
		
		String homepage="https://www.zlti.com/";
		HttpURLConnection huc=null;
		WebDriver driver=new ChromeDriver();
		driver.get(homepage);
		String url=null;
		int responsecode=200;
		
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		
		
		
	List<WebElement> li=	driver.findElements(By.tagName("a"));
	Iterator<WebElement> itr=li.iterator();
	while(itr.hasNext())
	{
		url=itr.next().getAttribute("href");
		System.out.println(url);
	
	
	if(url==null || url.isEmpty() )
		
	
		System.out.println("Url is not configured");
		
	
	
	
	
	
		huc=(HttpURLConnection)(new URL(url).openConnection());
		huc.setRequestMethod("HEAD");
		huc.connect();
		responsecode=huc.getResponseCode();
		if(responsecode>=400)
		
			System.out.println("This Url is a broken Url");
		
		else
		
			System.out.println("This Url is not a broken Url");
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
		
		

	}

}
