package TestNgExamples;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgParamexample1 {
	
	@Test
	@Parameters({"a","b"})
	public void Sum(int v1,int v2,int v3)
	{
		int sum=v1+v2+v3;
		System.out.println("The Sum value is  "+sum);
	}
	
	@Test
	@Parameters({"a","b"})
	public void difference(int v3,int v4)
	{
		int diff=v3-v4;
		System.out.println("The diff value is  "+diff);
	}
	
	

}
