package TestNgExamples;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class InheritedDataProviderExample {
	
	WebDriver driver;
	
	@Test(dataProvider="dp1",dataProviderClass=TestNgDataProviderExample.class)
	public void SearchGoogle(String k)
	{
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com");
		WebElement ele=	driver.findElement(By.xpath("//textarea[@id='APjFqb']"));
		ele.sendKeys(k);
		Reporter.log(k);
		ele.sendKeys(Keys.ENTER);
	}

}
