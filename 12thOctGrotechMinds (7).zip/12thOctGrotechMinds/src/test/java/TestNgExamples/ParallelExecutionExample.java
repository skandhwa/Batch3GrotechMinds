package TestNgExamples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ParallelExecutionExample {
	
	public WebDriver driver;
	
	@Test
	public void ChromeTest()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("Java");
		
		
	}
	
	@Test
	public void ChromeTest1()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("Java");
		
		
	}
	
	@Test
	public void ChromeTest2()
	{
		driver=new ChromeDriver();
		driver.get("https://www.amazon.com");
		
		
		
	}
	
	

}
